import turtle
import random
import time

def clicked(x, y):
    global points
    global time
    global start
    global cookieType
    global cookieDesign
    global randPoints


    if (time.time() - start) >= 60:
        wn.bgpic("nopic")
        wn.bgpic("BackgroundCropped.png")
        cookie.hideturtle()
        greenArrow.hideturtle()
        rightArrow.hideturtle()
        
        text.reset()
        text.clear()
        text.penup()
        text.color("white")
        text.goto(-250,-250)
        text.write(f"{points}")
        
        pen3.reset()
        pen3.clear()
        pen3.penup()
        pen3.color("white")
        pen3.goto(-250,-250)
        pen3.write(f"{randPoints}")
        
        pen4.reset()
        pen4.clear()
        pen4.penup()
        pen4.color("white")
        pen4.goto(-250,-250)
        pen4.write(f"{randPoints}")
        
        pen2.clear()
        pen2.penup()
        pen2.goto(0, 0)
        pen2.pendown()
        pen2.write(f"Times up", align="center", font=style)

        text2.write(f"Total points: {points}", align="center", font=style2)
            
    else:
        pen2.clear()
        pen2.write(f"Time: {int(time.time() - start)}", align="center", font=style)
    
    if cookieType == "good":
        randPoints = random.randint(1,10)
        points = points + randPoints
        pen3.clear()
        pen3.write(f'+ {randPoints}', font=style, align='center')
    elif cookieType == "bad":
        randPoints = random.randint(5,10)
        points = points - randPoints
        pen4.clear()
        pen4.write(f' - {randPoints}', font=style, align='center')
    
    text.clear()
    text.write(f'Points: {points}', font=style, align='center')

    cookieChoice = random.randint(1,10)
    if cookieChoice <= 8:
        cookieDesign = random.randint(1,3)
        if cookieDesign == 1:
            cookie.shape("Cookie1.gif")
            cookieType = "good"
        elif cookieDesign == 2:
            cookie.shape("Cookies2.gif")
            cookieType = "good"
        elif cookieDesign == 3:
            cookie.shape("Cookies3.gif")
            cookieType = "good"
            
    elif cookieChoice > 8:
        cookieDesign = random.randint(1,3)
        if cookieDesign == 1:
            cookie.shape("BadCookies.gif")
            cookieType = "bad"
        elif cookieDesign == 2:
            cookie.shape("BadCookies2.gif")
            cookieType = "bad"
        elif cookieDesign == 3:
            cookie.shape("BadCookies3.gif")
            cookieType = "bad"


def clicked2(x, y):
    global points
    global time
    global start
    global cookieType
    global cookieDesign
    global randPoints

    if (time.time() - start) >= 60:
        wn.bgpic("nopic")
        wn.bgpic("BackgroundCropped.png")
        cookie.hideturtle()
        greenArrow.hideturtle()
        rightArrow.hideturtle()
        
        text.reset()
        text.clear()
        text.penup()
        text.color("white")
        text.goto(-250,-250)
        text.write(f"{points}")
        
        pen3.reset()
        pen3.clear()
        pen3.color("white")
        pen3.penup()
        pen3.goto(-250,-250)
        pen3.write(f"{randPoints}")
        
        pen4.reset()
        pen4.clear()
        pen4.color("white")
        pen4.penup()
        pen4.goto(-250,-250)
        pen4.write(f"{randPoints}")
        
        pen2.clear()
        pen2.penup()
        pen2.goto(0,0)
        pen2.pendown()
        pen2.write(f"Times up", align="center", font=style)

        text2.write(f"Total points: {points}", align="center", font=style2)
            
    else:
        pen2.clear()
        pen2.write(f"Time: {int(time.time() - start)}", align="center", font=style)
    
    if cookieType == "good":
        randPoints = random.randint(5,10)
        points = points - randPoints
        pen3.clear()
        pen3.write(f'- {randPoints}', font=style, align='center')
    elif cookieType == "bad":
        randPoints = random.randint(1,10)
        points = points + randPoints
        pen4.clear()
        pen4.write(f'+ {randPoints}', font=style, align='center')

    text.clear()
    text.write(f'Points: {points}', font=style, align='center')

    cookieChoice = random.randint(1,10)
    if cookieChoice <= 8:
        cookieDesign = random.randint(1,3)
        if cookieDesign == 1:
            cookie.shape("Cookie1.gif")
            cookieType = "good"
        elif cookieDesign == 2:
            cookie.shape("Cookies2.gif")
            cookieType = "good"
        elif cookieDesign == 3:
            cookie.shape("Cookies3.gif")
            cookieType = "good"
    elif cookieChoice > 8:
        cookieDesign = random.randint(1,3)
        if cookieDesign == 1:
            cookie.shape("BadCookies.gif")
            cookieType = "bad"
        elif cookieDesign == 2:
            cookie.shape("BadCookies2.gif")
            cookieType = "bad"
        elif cookieDesign == 3:
            cookie.shape("BadCookies3.gif")
            cookieType = "bad"

def clickedStart(x,y):
    global clicks
    clicks = clicks + 1
    

wn = turtle.Screen()
wn.title("Cookie Clicker")
wn.bgpic("BackgroundCropped.png")

wn.register_shape("Cookie1.gif")
wn.register_shape("Cookies2.gif") 
wn.register_shape("Cookies3.gif") 

wn.register_shape("BadCookies.gif")
wn.register_shape("BadCookies2.gif") 
wn.register_shape("BadCookies3.gif") 

wn.register_shape("greenarrow.gif")
wn.register_shape("greenarrow2.gif") 
wn.register_shape("redarrow.gif")

wn.register_shape("BlueBubble.gif")
wn.register_shape("PurpleBubble.gif")

wn.setup(325,525)
start = "false"

wn.bgpic("StartCropped.png")

greenArrow2 = turtle.Turtle()
greenArrow2.penup()
greenArrow2.goto(10,-200)
greenArrow2.hideturtle()
greenArrow2.showturtle()
greenArrow2.shape("greenarrow2.gif")
clicks = 0

while start != "true":
    greenArrow2.onclick(clickedStart)
    if clicks == 1:
        wn.bgpic("RulesCropped.png")
    elif clicks == 2:
        wn.bgpic("Rules2Cropped.png")
    elif clicks == 3:
        wn.bgpic("BackgroundCropped.png")
        start = "true"
        greenArrow2.hideturtle()
    
clicks = 0
points = 0
start = time.time()

cookie = turtle.Turtle()
cookie.penup()
cookie.hideturtle()
cookie.showturtle()

cookieChoice = random.randint(1,10)
if cookieChoice <= 8:
    cookie.shape("Cookie1.gif")
    cookieType = "good"
elif cookieChoice > 8:
    cookie.shape("BadCookies.gif")
    cookieType = "bad"

text = turtle.Turtle()
text.hideturtle()

#points text
text.penup()
text.goto(25,200)
text.pendown()
text.hideturtle()
text.color("dark blue")
style = ('Arial', 30, 'italic')
style2 = ('Arial', 20, 'italic')

#points for final page
text2 = turtle.Turtle()
text2.hideturtle()
text2.penup()
text2.goto(0, -45)
text2.pendown()
text2.hideturtle()
text2.color("dark blue")


#time text
pen2 = turtle.Turtle()
pen2.hideturtle()
pen2.color("purple")
pen2.penup()
pen2.goto(30,155)
pen2.pendown()
pen2.color("purple")
style = ('Arial', 30, 'italic')

#good cookie points
pen3 = turtle.Turtle()
pen3.hideturtle()
pen3.penup()
pen3.color("purple")
pen3.goto(100,0)
pen3.pendown()

#bad cookie points
pen4 = turtle.Turtle()
pen4.hideturtle()
pen4.penup()
pen4.color("dark blue")
pen4.goto(-100,0)
pen4.pendown()

#green arrow
greenArrow = turtle.Turtle()
greenArrow.penup()
greenArrow.goto(-75,-110)
greenArrow.hideturtle()
greenArrow.showturtle()
greenArrow.shape("greenarrow.gif")

#red arrow
rightArrow = turtle.Turtle()
rightArrow.penup()
rightArrow.goto(75,-110)
rightArrow.hideturtle()
rightArrow.showturtle()
rightArrow.shape("redarrow.gif")



greenArrow.onclick(clicked)
rightArrow.onclick(clicked2)
wn.mainloop()


