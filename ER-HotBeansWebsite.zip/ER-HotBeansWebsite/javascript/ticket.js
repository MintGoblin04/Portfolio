// JavaScript Document

function total(frm) 
{
    var grandtotal         = 0; //sets variable grand total to £0
    var checkboxes  = document.forms[frm.id].elements["checkbox"]; // gets value & stores in variable from html id known as checkboxes
    var quantity      = document.forms[frm.id].elements["quantity"]; // gets value & stores in variable from html id known as quantity
    
    for (var i = 0; i < checkboxes.length; i++) 
    {
        if (checkboxes[i].checked) 
        {
            // if tabIndex correctly specified
            if (checkboxes[i].tabIndex == quantity[i].tabIndex)
                // works out grand total by adding all checked check boxes multiplied by quantities taken from input boxes
                grandtotal += Number(checkboxes[i].value) * Number(quantity[i].value);
            else
                // alert user with an error message
                alert('Seems to be an error');
        }
    }
    document.getElementById("totalDiv").firstChild.data = "£" + grandtotal; // displays grand total in totaldiv box
}


function checkout()
{
    var outputmessage = ""; // declares output message - left blank
    var checkboxes  = document.forms["ticketcalc"].elements["checkbox"]; // gets value & stores in variable from html id known as checkboxes
    var quantity      = document.forms["ticketcalc"].elements["quantity"]; // gets value & stores in variable from html id known as quantity
    
    for (var i=0; i < checkboxes.length; i++) 
    {
        if (checkboxes[i].checked) 
        {
            switch(checkboxes[i].tabIndex)
            {
                case 1: outputmessage += "Adult Ticket"; break; //checks condition of checked checkbox and displays appropriate output
                case 2: outputmessage += "Childs Ticket"; break;
                case 3: outputmessage += "OAP Ticket"; break               	
 
            }
            
            outputmessage += "<p>     <br> Quantity:   " + Number(quantity[i].value) + " <br> Price: £" +                      Number(checkboxes[i].value) * Number(quantity[i].value) + "<br><br><br></p>\n"; //complete message from case statement by displaying quantity & price selected
        }
    }   
   
    outputmessage += " <br>\n Grand Total:   " + 	document.getElementById("totalDiv").firstChild.data; //displays grand total in totaldiv id
    
   	document.getElementById('summary').innerHTML = outputmessage;; //displays output in div id known as summary
    
    
    
  }