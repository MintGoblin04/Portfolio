﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim MyNumbers(4) As Integer
        Dim i As Integer
        Dim MyString(4) As String
        MyNumbers(0) = 10
        MyNumbers(1) = 20
        MyNumbers(2) = 30
        MyNumbers(3) = 40
        MyNumbers(4) = 50
        MyString(0) = "This"
        MyString(1) = "is"
        MyString(2) = "a"
        MyString(3) = "String"
        MyString(4) = "Array"

        For i = 0 To 4
            ListBox1.Items.Add(MyNumbers(i))
        Next

        For i = 0 To 4
            ListBox1.Items.Add(MyString(i))
        Next


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim numbers(10) As Integer
        Dim times As Integer
        Dim StoreAnswer As Integer
        Dim i As Integer

        ListBox1.Items.Clear()
        times = Val(TextBox1.Text)
        For i = 1 To 10
            StoreAnswer = i * times
            numbers(i) = StoreAnswer
            ListBox1.Items.Add(times & " times " & i & " = " & numbers(i))

        Next i
    End Sub
End Class
