﻿Public Class Form1
    Dim f, c As Decimal

    Private Sub btnCalf_Click(sender As Object, e As EventArgs) Handles btnCalf.Click
        c = txtCent.Text
        f = c * 9 / 5 + 32
        lblFahr.Text = Format(f, "#0.00")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtCent.Text = ''
        txtFahr.Text = ''
        lblFahr.Text = ''
        lblCent.Text = ''
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        f = txtFahr.Text
        c = 5 * (f - 32) / 9
        lblCent.Text = Format(c, "#0.00")
        If lblCent.Text < 0 Then
            lblCent.BackColor = Color.Blue
        End If
        If lblCent.Text <= 20 Then
            lblCent.BackColor = Color.Yellow
        End If
        If lblCent.Text > 20 Then
            lblCent.BackColor = Color.Orange
        End If
    End Sub
End Class
